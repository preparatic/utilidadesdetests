/*******************************************************************************
 * Copyright (c) 2013, 2016 Prepartic and others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *******************************************************************************/

var questions = new Array();
var choices = new Array();
var answers = new Array();
var response = new Array();
var units = new Array();
var comments = new Array();
var preguntaids = new Array();

//  Id pregunta: 280 A�o de creaci�n de pregunta: 2016
 questions[0]= "1)  El pacto fiscal europeo de 2012 incluye:";
 choices[0]= new Array();
 choices[0][0] = "Un conjunto de reglas, llamadas &quot;reglas de oro&quot;, que son vinculantes en la UE para el principio de equilibrio presupuestario.";
 choices[0][1] = "Un compromiso de contar con un d&eacute;ficit estructural que no debe superar el 0,6% de la PIB.";
 choices[0][2] = "Un compromiso de poner las nuevas reglas en la constituci&oacute;n o en otras partes de la legislaci&oacute;n nacional, lo cual no necesita ser verificado por el Tribunal de Justicia de la Uni&oacute;n Europea.";
 choices[0][3] = "La obligaci&oacute;n de mantener siempre el d&eacute;ficit p&uacute;blico por debajo del 2.8 % del PIB.";
 answers[0] = choices[0][0];
 units[0] = "5";
 comments[0] = "Id Pregunta: 280. UNION EUROPEA";
 preguntaids[0] = 280


//  Id pregunta: 272 A�o de creaci�n de pregunta: 2016
 questions[1]= "2)  Respecto a SonarQube, se&ntilde;ale la FALSA";
 choices[1]= new Array();
 choices[1][0] = "Sirve para evaluar aspectos como la complejidad ciclom&aacute;tica del c&oacute;digo.";
 choices[1][1] = "Anteriormente se denominaba Sonar.";
 choices[1][2] = "Permite disponer de una matriz de dependencia entre objetos.";
 choices[1][3] = "Integra herramientas de medici&oacute;n de la calidad de c&oacute;digo como CPD, findbugs, PMD, checkstyle.";
 answers[1] = choices[1][2];
 units[1] = "92";
 comments[1] = "Id Pregunta: 272. INTEGRACION CONTINUA";
 preguntaids[1] = 272


//  Id pregunta: 273 A�o de creaci�n de pregunta: 2016
 questions[2]= "3)  Se&ntilde;ale la opci&oacute;n correcta";
 choices[2]= new Array();
 choices[2][0] = "Jenkins un servidor de integraci&oacute;n continua comercial.";
 choices[2][1] = "Extiende su funcionalidad a trav&eacute;s de plugins.";
 choices[2][2] = "Solamente soporta herramientas de control de versiones como CVS, Gity Clearcase.";
 choices[2][3] = "No posee un historial de cambios realizados por build o versi&oacute;n.";
 answers[2] = choices[2][1];
 units[2] = "92";
 comments[2] = "Id Pregunta: 273. INTEGRACION CONTINUA";
 preguntaids[2] = 273


//  Id pregunta: 736 A�o de creaci�n de pregunta: 2016
 questions[3]= "4)  En el Plan de Transformaci&oacute;n Digital de la AGE y sus OOPP el principio de transparencia:";
 choices[3]= new Array();
 choices[3][0] = "El seguimiento de la actividad de los funcionarios aumenta la eficacia de los servicios p&uacute;blicos.";
 choices[3][1] = "La transparencia facilita al ciudadano el acceso a los servicios p&uacute;blicos.";
 choices[3][2] = "Una continua monitorizaci&oacute;n de la actividad, junto a la evaluaci&oacute;n y difusi&oacute;n de resultados incrementa la satisfacci&oacute;n de los ciudadanos.";
 choices[3][3] = "El seguimiento y control de la actividad pol&iacute;tica disminuye las actividades ligadas a la corrupci&oacute;n.";
 answers[3] = choices[3][2];
 units[3] = "28";
 comments[3] = "Id Pregunta: 736. Estrategia TIC";
 preguntaids[3] = 736


//  Id pregunta: 352 A�o de creaci�n de pregunta: 2016
 questions[4]= "5)  La Comisi&oacute;n est&aacute; compuesta por:";
 choices[4]= new Array();
 choices[4][0] = "27 miembros, nacionales de los Estados comunitarios.";
 choices[4][1] = "20 miembros, sin que el n&uacute;mero de los componentes en posesi&oacute;n de la nacionalidad de un mismo Estado pueda ser superior a 3.";
 choices[4][2] = "25 miembros, nacionales de los Estados comunitarios.";
 choices[4][3] = "d)22 miembros, sin que el n&uacute;mero de los componentes en posesi&oacute;n de la nacionalidad de un mismo Estado pueda ser superior a 3.";
 answers[4] = choices[4][0];
 units[4] = "5";
 comments[4] = "Id Pregunta: 352. UNION EUROPEA";
 preguntaids[4] = 352


//  Id pregunta: 843 A�o de creaci�n de pregunta: 2016
 questions[5]= "6)  Ley 40/2015, de 1 de octubre, de R&eacute;gimen Jur&iacute;dico del Sector P&uacute;blico. Se&ntilde;ale la respuesta incorrecta.";
 choices[5]= new Array();
 choices[5][0] = "De cada sesi&oacute;n que celebre el &oacute;rgano colegiado se levantar&aacute; acta por el Secretario, que especificar&aacute; necesariamente los asistentes, el orden del d&iacute;a de la reuni&oacute;n, las circunstancias del lugar y tiempo en que se ha celebrado, los puntos principales de las deliberaciones, as&iacute; como el contenido de los acuerdos adoptados.";
 choices[5][1] = "Podr&aacute;n grabarse las sesiones que celebre el &oacute;rgano colegiado. El fichero resultante de la grabaci&oacute;n, junto con la certificaci&oacute;n expedida por el Secretario de la autenticidad e integridad del mismo, y cuantos documentos en soporte electr&oacute;nico se utilizasen como documentos de la sesi&oacute;n, podr&aacute;n acompa&ntilde;ar al acta de las sesiones, sin necesidad de hacer constar en ella los puntos principales de las deliberaciones.";
 choices[5][2] = "El acta de cada sesi&oacute;n podr&aacute; aprobarse en la misma reuni&oacute;n o en una reuni&oacute;n posterior. El Secretario elaborar&aacute; el acta con el visto bueno del Presidente y lo remitir&aacute; a trav&eacute;s de medios electr&oacute;nicos, a los miembros del &oacute;rgano colegiado, quienes podr&aacute;n manifestar por los mismos medios su conformidad o reparos al texto, a efectos de su aprobaci&oacute;n, consider&aacute;ndose, en caso afirmativo, aprobada en la misma reuni&oacute;n.";
 choices[5][3] = "Cuando se hubiese optado por la grabaci&oacute;n de las sesiones celebradas o por la utilizaci&oacute;n de documentos en soporte electr&oacute;nico, deber&aacute;n conservarse de forma que se garantice la integridad y autenticidad de los ficheros electr&oacute;nicos correspondientes y el acceso a los mismos por parte de los miembros del &oacute;rgano colegiado.";
 answers[5] = choices[5][2];
 units[5] = "4, 7, 8, 9";
 comments[5] = "Id Pregunta: 843. Ley 40/2015";
 preguntaids[5] = 843


//  Id pregunta: 218 A�o de creaci�n de pregunta: 2016
 questions[6]= "7)  Seg&uacute;n el T&iacute;tulo III &quot;De las Cortes Generales&quot; de la Constituci&oacute;n Espa&ntilde;ola, las C&aacute;maras podr&aacute;n:";
 choices[6]= new Array();
 choices[6][0] = "Recibir peticiones individuales y colectivas, siempre por escrito, quedando prohibida la presentaci&oacute;n directa por manifestaciones ciudadanas.";
 choices[6][1] = "Delegar en las Comisiones Legislativas Permanentes la aprobaci&oacute;n de proyectos o proposiciones de ley relativas a cuestiones internacionales.";
 choices[6][2] = "Reunirse en sesi&oacute;n extraordinaria a petici&oacute;n de la mayor&iacute;a simple de los miembros de cualquiera de las C&aacute;maras.";
 choices[6][3] = "Nombrar conjuntamente Comisiones de Investigaci&oacute;n sobre asuntos de inter&eacute;s p&uacute;blico. Sus conclusiones ser&aacute;n vinculantes para los Tribunales.";
 answers[6] = choices[6][0];
 units[6] = "1";
 comments[6] = "Id Pregunta: 218. CONSTITUCION1978";
 preguntaids[6] = 218


//  Id pregunta: 136 A�o de creaci�n de pregunta: 2016
 questions[7]= "8)  La Ley 15/2014, de racionalizaci&oacute;n del Sector P&uacute;blico y otras medidas de reforma administrativa, no incluye:";
 choices[7]= new Array();
 choices[7][0] = "Modificaci&oacute;n de la Ley General Presupuestaria para permitir de manera m&aacute;s eficaz el control de las cuentas corrientes en las que se sit&uacute;an fondos de Tesoro P&uacute;blico.";
 choices[7][1] = "Permiso para la reordenaci&oacute;n de organismos p&uacute;blicos con el fin de mejorar su eficiencia y reducir el gasto p&uacute;blico.";
 choices[7][2] = "Modificaci&oacute;n normativa para hacer uso de certificados electr&oacute;nicos &uacute;nicos para grupos o colectivos de personas f&iacute;sicas.";
 choices[7][3] = "Implantaci&oacute;n del BOE como Tabl&oacute;n Edictal &Uacute;nico para la realizaci&oacute;n de notificaciones administrativas.";
 answers[7] = choices[7][2];
 units[7] = "12";
 comments[7] = "Id Pregunta: 136. Leyes modelo econ&oacute;mico";
 preguntaids[7] = 136


//  Id pregunta: 761 A�o de creaci�n de pregunta: 2016
 questions[8]= "9)  &iquest;En cu&aacute;ntos pilares se fundamenta la Estrategia del Mercado &Uacute;nico Digital?";
 choices[8]= new Array();
 choices[8][0] = "3 pilares";
 choices[8][1] = "4 pilares";
 choices[8][2] = "5 pilares";
 choices[8][3] = "7 pilares";
 answers[8] = choices[8][0];
 units[8] = "17";
 comments[8] = "Id Pregunta: 761. Mercado &Uacute;nico Digital";
 preguntaids[8] = 761


//  Id pregunta: 337 A�o de creaci�n de pregunta: 2016
 questions[9]= "10)  &iquest;De cu&aacute;ntos diputados se compone el Parlamento Europeo?:";
 choices[9]= new Array();
 choices[9][0] = "732";
 choices[9][1] = "626";
 choices[9][2] = "786";
 choices[9][3] = "360";
 answers[9] = choices[9][2];
 units[9] = "5";
 comments[9] = "Id Pregunta: 337. UNION EUROPEA";
 preguntaids[9] = 337


//  Id pregunta: 751 A�o de creaci�n de pregunta: 2016
 questions[10]= "11)  En los or&iacute;genes te&oacute;ricos del t&eacute;rmino gobernanza se encuentra:";
 choices[10]= new Array();
 choices[10][0] = "Peters";
 choices[10][1] = "Hollingsworth";
 choices[10][2] = "Manuel Castells";
 choices[10][3] = "Gaebler";
 answers[10] = choices[10][1];
 units[10] = "20";
 comments[10] = "Id Pregunta: 751. Direcci&oacute;n p&uacute;blica";
 preguntaids[10] = 751


//  Id pregunta: 198 A�o de creaci�n de pregunta: 2016
 questions[11]= "12)  La Constituci&oacute;n Espa&ntilde;ola de 1978, estructura las Cortes Generales en:";
 choices[11]= new Array();
 choices[11][0] = "Dos c&aacute;maras: Congreso de los Diputados (C&aacute;mara Alta) y Senado (C&aacute;mara Baja).";
 choices[11][1] = "Consejo de Ministros y dos C&aacute;maras: Congreso de los Diputados (C&aacute;mara Alta) y Senado (C&aacute;mara Baja).";
 choices[11][2] = "Gobierno de la Naci&oacute;n y dos C&aacute;maras: Congreso de los Diputados (C&aacute;mara Alta) y Senado (C&aacute;mara Baja).";
 choices[11][3] = "Dos C&aacute;maras: Congreso de los Diputados (C&aacute;mara Baja) y Senado (C&aacute;mara Alta).";
 answers[11] = choices[11][3];
 units[11] = "1";
 comments[11] = "Id Pregunta: 198. CONSTITUCION1978";
 preguntaids[11] = 198


//  Id pregunta: 326 A�o de creaci�n de pregunta: 2016
 questions[12]= "13)  La Mesa del Parlamento estar&aacute; compuesta por:";
 choices[12]= new Array();
 choices[12][0] = "El Presidente, doce Vicepresidentes y los Cuestores.";
 choices[12][1] = "El Presidente, diez Vicepresidentes y los Cuestores.";
 choices[12][2] = "El Presidente, dos Vicepresidentes y los Cuestores.";
 choices[12][3] = "El Presidente, catorce Vicepresidentes y los Cuestores.";
 answers[12] = choices[12][3];
 units[12] = "5";
 comments[12] = "Id Pregunta: 326. UNION EUROPEA";
 preguntaids[12] = 326


//  Id pregunta: 20 A�o de creaci�n de pregunta: 2016
 questions[13]= "14)  Con respecto al &aacute;mbito objetivo de aplicaci&oacute;n de la Ley 37/2007, de 16 de noviembre, sobre reutilizaci&oacute;n de la informaci&oacute;n del sector p&uacute;blico:";
 choices[13]= new Array();
 choices[13][0] = "Abarca el intercambio de documentos entre Administraciones y organismos del sector p&uacute;blico en el ejercicio de las funciones p&uacute;blicas que tengan atribuidas.";
 choices[13][1] = "Ser&aacute; aplicable incluso sobre los documentos que obran en las Administraciones y organismos del sector p&uacute;blico para finalidades ajenas a sus funciones de servicio p&uacute;blico.";
 choices[13][2] = "No afecta a la existencia de derechos de propiedad intelectual de las Administraciones y organismos del sector p&uacute;blico ni a su posesi&oacute;n por &eacute;stos.";
 choices[13][3] = "Fija la prevalencia del derecho fundamental a la protecci&oacute;n de datos de car&aacute;cter personal, a&uacute;n cuando se apliquen medidas de disociaci&oacute;n de datos.";
 answers[13] = choices[13][2];
 units[13] = "27";
 comments[13] = "Id Pregunta: 20. AGE A1 2015";
 preguntaids[13] = 20


//  Id pregunta: 232 A�o de creaci�n de pregunta: 2016
 questions[14]= "15)  &iquest;Cu&aacute;l de los siguientes &oacute;rganos, de conformidad con la Constituci&oacute;n Espa&ntilde;ola, no tiene legitimidad para interponer el recurso de inconstitucionalidad?";
 choices[14]= new Array();
 choices[14][0] = "El Presidente del Senado.";
 choices[14][1] = "El Defensor del Pueblo.";
 choices[14][2] = "Las Asambleas de las Comunidades Aut&oacute;nomas.";
 choices[14][3] = "El Presidente del Gobierno.";
 answers[14] = choices[14][2];
 units[14] = "1";
 comments[14] = "Id Pregunta: 232. CONSTITUCION1978";
 preguntaids[14] = 232


//  Id pregunta: 379 A�o de creaci�n de pregunta: 2016
 questions[15]= "16)  Seg&uacute;n recoge la Ley Org&aacute;nica 3/2007, de 22 de marzo, para la igualdad efectiva de mujeres y hombres, &iquest;con qu&eacute; frecuencia debe elaborar el Gobierno un informe sobre el conjunto de actuaciones en relaci&oacute;n con le efectividad del principio de igualdad entre mujeres y hombres?";
 choices[15]= new Array();
 choices[15][0] = "Anual.";
 choices[15][1] = "Semestral.";
 choices[15][2] = "Seg&uacute;n se determine reglamentariamente.";
 choices[15][3] = "Bienal.";
 answers[15] = choices[15][2];
 units[15] = "14";
 comments[15] = "Id Pregunta: 379. POLITICAS DE IGUALDAD";
 preguntaids[15] = 379


//  Id pregunta: 818 A�o de creaci�n de pregunta: 2016
 questions[16]= "17)  Los Directores Insulares de la Administraci&oacute;n General del Estado (se&ntilde;ala la incorrecta):";
 choices[16]= new Array();
 choices[16][0] = "ser&aacute;n nombrados por el Delegado del Gobierno mediante el procedimiento de concurso-oposici&oacute;n";
 choices[16][1] = "ser&aacute;n nombrados entre funcionarios de carrera del Estado, de las Comunidades Aut&oacute;nomas o de las Entidades Locales, pertenecientes a Cuerpos o Escalas clasificados como Subgrupo A1";
 choices[16][2] = "dependen jer&aacute;rquicamente del Delegado del Gobierno en la Comunidad Aut&oacute;noma o del Subdelegado del Gobierno en la provincia, cuando este cargo exista";
 choices[16][3] = "ejercen, en su &aacute;mbito territorial, las competencias atribuidas por esta Ley a los Subdelegados del Gobierno en las provincias";
 answers[16] = choices[16][0];
 units[16] = "4, 7, 8, 9";
 comments[16] = "Id Pregunta: 818. Ley 40/2015";
 preguntaids[16] = 818


//  Id pregunta: 611 A�o de creaci�n de pregunta: 2016
 questions[17]= "18)  Dentro de las t&eacute;cnicas de clasificaci&oacute;n de datos tenemos los m&eacute;todos de clasificaci&oacute;n interna. &iquest;A qu&eacute; tipo de algoritmo de ordenaci&oacute;n o clasificaci&oacute;n pertenece el m&eacute;todo de la burbuja?";
 choices[17]= new Array();
 choices[17][0] = "Clasificaci&oacute;n por inserci&oacute;n.";
 choices[17][1] = "Clasificaci&oacute;n por cuenta.";
 choices[17][2] = "Clasificaci&oacute;n por selecci&oacute;n.";
 choices[17][3] = "Clasificaci&oacute;n por intercambio.";
 answers[17] = choices[17][3];
 units[17] = "56";
 comments[17] = "Id Pregunta: 611. Junta de Extremadura A1 2015";
 preguntaids[17] = 611


//  Id pregunta: 149 A�o de creaci�n de pregunta: 2016
 questions[18]= "19)  Seg&uacute;n establece la Ley 39/2015, las Administraciones P&uacute;blicas har&aacute;n p&uacute;blico un Plan Normativo que:";
 choices[18]= new Array();
 choices[18][0] = "Contendr&aacute; las iniciativas legales y reglamentarias que hayan sido aprobadas en el a&ntilde;o en curso y se publicar&aacute; en el Portal de la Transparencia de la Administraci&oacute;n P&uacute;blica correspondiente";
 choices[18][1] = "Contendr&aacute; exclusivamente las iniciativas legales que vayan a ser elevadas para su aprobaci&oacute;n en el a&ntilde;o siguiente y se publicar&aacute; en el Portal de la Transparencia de la Administraci&oacute;n P&uacute;blica correspondiente";
 choices[18][2] = "Contendr&aacute; las iniciativas legales o reglamentarias que vayan a ser elevadas para su aprobaci&oacute;n en el a&ntilde;o siguiente y se publicar&aacute; en el Portal de la Transparencia de la Administraci&oacute;n P&uacute;blica correspondiente";
 choices[18][3] = "Contendr&aacute; las iniciativas legales o reglamentarias que vayan a ser elevadas para su aprobaci&oacute;n en el a&ntilde;o siguiente y se publicar&aacute; en el Bolet&iacute;n Oficial de la Administraci&oacute;n P&uacute;blica correspondiente";
 answers[18] = choices[18][2];
 units[18] = "7";
 comments[18] = "Id Pregunta: 149. Ley 39/2015, Art&iacute;culo 132";
 preguntaids[18] = 149


//  Id pregunta: 766 A�o de creaci�n de pregunta: 2016
 questions[19]= "20)  El sector p&uacute;blico institucional se integra por:";
 choices[19]= new Array();
 choices[19][0] = "cualesquiera organismos p&uacute;blicos y entidades de derecho p&uacute;blico vinculados o dependientes de las Administraciones P&uacute;blicas";
 choices[19][1] = "las entidades de derecho privado vinculadas o dependientes de las Administraciones P&uacute;blicas";
 choices[19][2] = "las Universidades p&uacute;blicas";
 choices[19][3] = "todas son correctas";
 answers[19] = choices[19][3];
 units[19] = "4, 7, 8, 9";
 comments[19] = "Id Pregunta: 766. Ley 40/2015";
 preguntaids[19] = 766


//  Id pregunta: 321 A�o de creaci�n de pregunta: 2016
 questions[20]= "21)  Indique el n&uacute;mero de Diputados del Parlamento Europeo que actualmente le corresponden a Espa&ntilde;a:";
 choices[20]= new Array();
 choices[20][0] = "Cincuenta y cuatro.";
 choices[20][1] = "Cincuenta.";
 choices[20][2] = "Cincuenta y cinco.";
 choices[20][3] = "Cincuenta y dos.";
 answers[20] = choices[20][1];
 units[20] = "5";
 comments[20] = "Id Pregunta: 321. UNION EUROPEA";
 preguntaids[20] = 321


//  Id pregunta: 74 A�o de creaci�n de pregunta: 2016
 questions[21]= "22)  Se&ntilde;ale la opci&oacute;n incorrecta respecto a SMTP:";
 choices[21]= new Array();
 choices[21][0] = "SMTP es capaz de transportar correo a trav&eacute;s de m&uacute;ltiples redes: entre nodos conectados por TCP en Internet, entre nodos conectados en una Intranet TCP/IP aislados por un cortafuegos, o entre nodos en un entorno LAN o WAN que est&eacute;n usando un protocolo de nivel de transporte distinto a TCP.";
 choices[21][1] = "Usando SMTP, un proceso puede transferir correo a otro proceso en la misma red o a otra red mediante un proceso gateway accesible en las dos redes.";
 choices[21][2] = "En SMTP un mensaje de correo puede pasar por una serie de nodos gateway intermedios en su camino desde el emisor al receptor &uacute;ltimo, sirvi&eacute;ndose de mecanismos para decidir el siguiente salto como el sistema de resoluci&oacute;n de nombres de dominio de Internet.";
 choices[21][3] = "En SMTP la transferencia de mensaje ocurre siempre en una conexi&oacute;n &uacute;nica entre el emisor SMTP y el receptor final SMTP.";
 answers[21] = choices[21][3];
 units[21] = "106";
 comments[21] = "Id Pregunta: 74. AGE A1 2015";
 preguntaids[21] = 74


//  Id pregunta: 855 A�o de creaci�n de pregunta: 2016
 questions[22]= "23)  Indique cu&aacute;l de las siguientes funciones relativas a una PKI es INCORRECTA:";
 choices[22]= new Array();
 choices[22][0] = "Garantiza mediante el uso de certificados digitales el no repudio, integridad, autenticaci&oacute;n y la publicaci&oacute;n de los datos transmitidos.";
 choices[22][1] = "Los componentes de una PKI para la administraci&oacute;n de los ccertificados son: software, hardware, personas, pol&iacute;ticas, procedimientos.";
 choices[22][2] = "Entre las funciones de una PKI se encuentra la revocaci&oacute;n de claves.";
 choices[22][3] = "Entre las funciones de una PKI se encuentran la generaci&oacute;n, recuperaci&oacute;n y renovaci&oacute;n de claves.";
 answers[22] = choices[22][0];
 units[22] = "76";
 comments[22] = "Id Pregunta: 855. Xunta de Galicia 2015";
 preguntaids[22] = 855


//  Id pregunta: 410 A�o de creaci�n de pregunta: 2016
 questions[23]= "24)  La Administraci&oacute;n General del Estado, utilizar&aacute; entre otros instrumentos b&aacute;sicos para la consecuci&oacute;n del principio de igualdad:";
 choices[23]= new Array();
 choices[23][0] = "Un plan estrat&eacute;gico de igualdad de oportunidades.";
 choices[23][1] = "Un objetivo espec&iacute;fico de igualdad.";
 choices[23][2] = "Un programa de igualdad.";
 choices[23][3] = "Un estatuto de igualdad.";
 answers[23] = choices[23][0];
 units[23] = "14";
 comments[23] = "Id Pregunta: 410. POLITICAS DE IGUALDAD";
 preguntaids[23] = 410


//  Id pregunta: 578 A�o de creaci�n de pregunta: 2016
 questions[24]= "25)  Se&ntilde;ale, de entre los siguientes, cu&aacute;l es un gestor de base de datos relacional:";
 choices[24]= new Array();
 choices[24][0] = "PostgreSQL";
 choices[24][1] = "Datawarehouse";
 choices[24][2] = "Snowflake";
 choices[24][3] = "CouchDB";
 answers[24] = choices[24][0];
 units[24] = "61";
 comments[24] = "Id Pregunta: 578. Tema 61. TAI 2016.";
 preguntaids[24] = 578


//  Id pregunta: 431 A�o de creaci�n de pregunta: 2016
 questions[25]= "26)  En el supuesto de que una empresa haga publicidad enga&ntilde;osa de sus acciones de responsabilidad en materia de igualdad, podr&aacute;n ejercer la acci&oacute;n de cesaci&oacute;n cuando se considere:";
 choices[25]= new Array();
 choices[25][0] = "El Instituto de la Mujer.";
 choices[25][1] = "&Oacute;rganos equivalentes al anterior pertenecientes a las CCAA.";
 choices[25][2] = "Ambas son correctas.";
 choices[25][3] = "A y B son incorrectas.";
 answers[25] = choices[25][2];
 units[25] = "14";
 comments[25] = "Id Pregunta: 431. POLITICAS DE IGUALDAD";
 preguntaids[25] = 431


//  Id pregunta: 759 A�o de creaci�n de pregunta: 2016
 questions[26]= "27)  &iquest;Cu&aacute;l de las siguientes no es una prioridad propuesta por la Estrategia Europa 2020?";
 choices[26]= new Array();
 choices[26][0] = "Crecimiento sostenible";
 choices[26][1] = "Crecimiento inteligente";
 choices[26][2] = "Crecimiento digital";
 choices[26][3] = "Crecimiento integrador";
 answers[26] = choices[26][2];
 units[26] = "19";
 comments[26] = "Id Pregunta: 759. Europa 2020";
 preguntaids[26] = 759


//  Id pregunta: 333 A�o de creaci�n de pregunta: 2016
 questions[27]= "28)  Est&aacute;n legitimados para interponer el recurso de carencia del art. 175 TCE:";
 choices[27]= new Array();
 choices[27][0] = "Las instituciones comunitarias.";
 choices[27][1] = "Los Estados miembros y las instituciones comunitarias.";
 choices[27][2] = "Los Estados miembros.";
 choices[27][3] = "Los nacionales de los Estados miembros.";
 answers[27] = choices[27][1];
 units[27] = "5";
 comments[27] = "Id Pregunta: 333. UNION EUROPEA";
 preguntaids[27] = 333


//  Id pregunta: 406 A�o de creaci�n de pregunta: 2016
 questions[28]= "29)  &iquest;Qu&eacute; art&iacute;culo de la Constituci&oacute;n Espa&ntilde;ola garantiza la no discriminaci&oacute;n por raz&oacute;n de sexo?";
 choices[28]= new Array();
 choices[28][0] = "Art&iacute;culo 9.1 CE.";
 choices[28][1] = "Art&iacute;culo 53 CE.";
 choices[28][2] = "Art&iacute;culo 14 CE.";
 choices[28][3] = "Art&iacute;culo 16 CE.";
 answers[28] = choices[28][2];
 units[28] = "14";
 comments[28] = "Id Pregunta: 406. POLITICAS DE IGUALDAD";
 preguntaids[28] = 406


//  Id pregunta: 853 A�o de creaci�n de pregunta: 2016
 questions[29]= "30)  Si disponemos de 8 discos SAS de 1TB netos configurados en RAID1, &iquest;de qu&eacute; capacidad neta se dispone en RAID1 en el sistema de almacenamiento?";
 choices[29]= new Array();
 choices[29][0] = "6 TB.";
 choices[29][1] = "8 TB.";
 choices[29][2] = "7 TB.";
 choices[29][3] = "4 TB.";
 answers[29] = choices[29][3];
 units[29] = "53";
 comments[29] = "Id Pregunta: 853. Xunta de Galicia 2015";
 preguntaids[29] = 853


//  Id pregunta: 568 A�o de creaci�n de pregunta: 2016
 questions[30]= "31)  Cuando decimos que la inversi&oacute;n extranjera en Espa&ntilde;a tiene un car&aacute;cter proc&iacute;clico, nos referimos a que:";
 choices[30]= new Array();
 choices[30][0] = "Aumenta cuando la econom&iacute;a est&aacute; en crecimiento, y se reduce cuando el pa&iacute;s entra en recesi&oacute;n";
 choices[30][1] = "Se reduce cuando la econom&iacute;a est&aacute; en crecimiento, y aumenta cuando el pa&iacute;s entra en recesi&oacute;n";
 choices[30][2] = "Aumenta cuando el pa&iacute;s entra en recesi&oacute;n, y aumenta cuando la econom&iacute;a est&aacute; en crecimiento";
 choices[30][3] = "Se reduce cuando el pa&iacute;s entra en recesi&oacute;n, y se reduce cuando la econom&iacute;a est&aacute; en crecimiento";
 answers[30] = choices[30][0];
 units[30] = "12";
 comments[30] = "Id Pregunta: 568. Modelo econ&oacute;mico";
 preguntaids[30] = 568


//  Id pregunta: 25 A�o de creaci�n de pregunta: 2016
 questions[31]= "32)  &iquest;Mediante qu&eacute; tipo de objetos se implementa el acceso a los recursos gestionados con la tecnolog&iacute;a JMX?";
 choices[31]= new Array();
 choices[31][0] = "SessionBean";
 choices[31][1] = "JavaBean";
 choices[31][2] = "MBeans";
 choices[31][3] = "MessageDrivenBean";
 answers[31] = choices[31][2];
 units[31] = "64";
 comments[31] = "Id Pregunta: 25. AGE A1 2015";
 preguntaids[31] = 25


//  Id pregunta: 624 A�o de creaci�n de pregunta: 2016
 questions[32]= "33)  Qu&eacute; nombre reciben las unidades de almacenamieto de las que est&aacute; compuesta un documento XML?";
 choices[32]= new Array();
 choices[32][0] = "Entradas (entities).";
 choices[32][1] = "Atributos (attribs).";
 choices[32][2] = "M&oacute;dulos (modules).";
 choices[32][3] = "Objetos (objects).";
 answers[32] = choices[32][0];
 units[32] = "74";
 comments[32] = "Id Pregunta: 624. Junta de Extremadura A1 2015";
 preguntaids[32] = 624


//  Id pregunta: 481 A�o de creaci�n de pregunta: 2016
 questions[33]= "34)  Conforme a Ley 47/2003, de 26 de noviembre, General Presupuestaria, en el Presupuesto del Estado, los cr&eacute;ditos destinados a atenciones protocolarias y representativas se especificar&aacute;n:";
 choices[33]= new Array();
 choices[33][0] = "A nivel de art&iacute;culo.";
 choices[33][1] = "A nivel de cap&iacute;tulo.";
 choices[33][2] = "Al nivel que corresponda conforme a su concreta clasificaci&oacute;n econ&oacute;mica.";
 choices[33][3] = "A nivel de concepto.";
 answers[33] = choices[33][2];
 units[33] = "10";
 comments[33] = "Id Pregunta: 481. PRESUPUESTOS GENERALES";
 preguntaids[33] = 481


//  Id pregunta: 470 A�o de creaci�n de pregunta: 2016
 questions[34]= "35)  De acuerdo con la Ley 47/2003, de 26 de noviembre, General Presupuestaria, elaborar la documentaci&oacute;n estad&iacute;stico-contable de car&aacute;cter oficial del Sistema de la Seguridad Social es una competencia de:";
 choices[34]= new Array();
 choices[34][0] = "El Ministerio de Hacienda.";
 choices[34][1] = "El Ministerio de Econom&iacute;a.";
 choices[34][2] = "La Intervenci&oacute;n General de la Administraci&oacute;n del Estado.";
 choices[34][3] = "Ninguna de las respuestas es correcta.";
 answers[34] = choices[34][2];
 units[34] = "10";
 comments[34] = "Id Pregunta: 470. PRESUPUESTOS GENERALES";
 preguntaids[34] = 470


//  Id pregunta: 4 A�o de creaci�n de pregunta: 2016
 questions[35]= "36)  Un wireframe es:";
 choices[35]= new Array();
 choices[35][0] = "Un marco de referencia para el dise&ntilde;o y despliegue de redes WiFi.";
 choices[35][1] = "Un marco de referencia para el dise&ntilde;o y despliegue de redes WiMAX.";
 choices[35][2] = "Un modelo que permite evaluar el impacto de las nuevas tecnolog&iacute;as en la mejora de la calidad de vida durante la puesta en marcha de una ciudad inteligente (smart city).";
 choices[35][3] = "Una interfaz visual que representa la estructura visual de un sitio web y la relaci&oacute;n entre sus p&aacute;ginas.";
 answers[35] = choices[35][3];
 units[35] = "62";
 comments[35] = "Id Pregunta: 4. AGE A1 2015";
 preguntaids[35] = 4


//  Id pregunta: 863 A�o de creaci�n de pregunta: 2016
 questions[36]= "37)  Se recomienda que todas aquellas campa&ntilde;as de los ministerios que cuenten con su propia p&aacute;gina web, cuenten adem&aacute;s con un subdominio o URL secundaria en la estructura general de la p&aacute;gina web del Ministerio. Indique la opci&oacute;n correcta.";
 choices[36]= new Array();
 choices[36][0] = "Se podr&aacute; utilizar de forma opcional descripciones sem&aacute;nticas en el nombramiento y titulaci&oacute;n de los subdominios.";
 choices[36][1] = "RUN implementa una soluci&oacute;n sencilla de generaci&oacute;n de URL cortas  para una mejora en la eficiencia de la remisi&oacute;n de direcciones web mediante email, sms, twitter etc";
 choices[36][2] = "El nombre del subdominio o URL secundaria debe ser distinto al que se utilice como URL independiente.";
 choices[36][3] = "Con los subdominios o URL secundarias los robots de los buscadores requerir&aacute;n m&aacute;s tiempo en interpretar su dependencia contextual con el Ministerio u &Oacute;rgano de la Administraci&oacute;n.";
 answers[36] = choices[36][1];
 units[36] = "125";
 comments[36] = "Id Pregunta: 863. Gu&iacute;a de comunicaci&oacute;n digital";
 preguntaids[36] = 863


//  Id pregunta: 710 A�o de creaci�n de pregunta: 2016
 questions[37]= "38)  Indique la afirmaci&oacute;n falsa:";
 choices[37]= new Array();
 choices[37][0] = "En la publicidad activa la Administraci&oacute;n pone los datos a disposici&oacute;n de la ciudadan&iacute;a, en portales y p&aacute;ginas web, sin esperar a que los ciudadanos los demanden, proactivamente.";
 choices[37][1] = "En el derecho de acceso a la informaci&oacute;n p&uacute;blica los ciudadanos acceden a la informaci&oacute;n p&uacute;blica puesta a disposici&oacute;n por la Administraci&oacute;n en portales y p&aacute;ginas web.";
 choices[37][2] = "La publicidad activa y el derecho de acceso fomentan la transparencia en la actividad p&uacute;blica.";
 choices[37][3] = "En el derecho de acceso a la informaci&oacute;n p&uacute;blica la Administraci&oacute;n responde a las demandas de informaci&oacute;n por parte de los ciudadanos.";
 answers[37] = choices[37][1];
 units[37] = "22";
 comments[37] = "Id Pregunta: 710. Ley de transparencia";
 preguntaids[37] = 710


//  Id pregunta: 805 A�o de creaci�n de pregunta: 2016
 questions[38]= "39)  Los Secretarios generales t&eacute;cnicos tienen a todos los efectos la categor&iacute;a de:";
 choices[38]= new Array();
 choices[38][0] = "Director General";
 choices[38][1] = "Secretario general";
 choices[38][2] = "Subdirector general";
 choices[38][3] = "Subsecretario";
 answers[38] = choices[38][0];
 units[38] = "4, 7, 8, 9";
 comments[38] = "Id Pregunta: 805. Ley 40/2015";
 preguntaids[38] = 805


//  Id pregunta: 363 A�o de creaci�n de pregunta: 2016
 questions[39]= "40)  Los Reglamentos no se caracterizan por:";
 choices[39]= new Array();
 choices[39][0] = "No poseer alcance general.";
 choices[39][1] = "Ser obligatorios.";
 choices[39][2] = "Todas son caracter&iacute;sticas de los Reglamentos.";
 choices[39][3] = "Ser de aplicaci&oacute;n directa a los Estados miembros.";
 answers[39] = choices[39][0];
 units[39] = "5";
 comments[39] = "Id Pregunta: 363. UNION EUROPEA";
 preguntaids[39] = 363


//  Id pregunta: 413 A�o de creaci�n de pregunta: 2016
 questions[40]= "41)  Gozar&aacute;n de los derecho derivados del principio de igualdad de trato y de la prohibici&oacute;n de discriminaci&oacute;n por raz&oacute;n de sexo:";
 choices[40]= new Array();
 choices[40][0] = "La mujeres.";
 choices[40][1] = "Lo hombres.";
 choices[40][2] = "Todas las personas.";
 choices[40][3] = "Las mujeres y ni&ntilde;os menores de 16 a&ntilde;os.";
 answers[40] = choices[40][2];
 units[40] = "14";
 comments[40] = "Id Pregunta: 413. POLITICAS DE IGUALDAD";
 preguntaids[40] = 413


